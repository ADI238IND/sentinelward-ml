"""Checked offline entry point for the user-supplied M6 research artifact."""

from __future__ import annotations

import hashlib
import importlib.util
from pathlib import Path

import numpy as np

M6_SHA256 = "1594c6ef8a4f3f3b4c22f4785e90f01287757d5c26897b13903b7e77a0dd32b8"


class SentinelWardDriftMonitor:
    """Run M6 on a batch of native 250 Hz, two-channel research windows."""

    def __init__(self, root=None):
        import joblib

        base = Path(root) if root is not None else Path(__file__).resolve().parents[1]
        component = base / "components" / "SentinelWard_M6"
        model_path = component / "sentinelward_m6_drift_v1.joblib"
        if hashlib.sha256(model_path.read_bytes()).hexdigest() != M6_SHA256:
            raise ValueError("M6 artifact SHA-256 mismatch")
        spec = importlib.util.spec_from_file_location("sentinelward_m6_runtime", component / "m6_runtime.py")
        if spec is None or spec.loader is None:
            raise RuntimeError("M6 runtime is unavailable")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self._runtime = module
        self._bundle = joblib.load(model_path)  # Only the checked, repository-owned artifact.
        if self._bundle.get("sampling_rate_hz") != 250 or self._bundle.get("samples_per_window") != 2500:
            raise ValueError("M6 artifact input contract mismatch")

    @property
    def minimum_batch_size(self):
        return int(self._bundle["minimum_batch_size"])

    def monitor(self, signals, valid_masks, *, sample_rate_hz=250):
        if sample_rate_hz != 250:
            raise ValueError("M6 requires native 250 Hz inputs")
        x = np.asarray(signals)
        mask = np.asarray(valid_masks)
        if x.ndim != 3 or x.shape[1:] != (2, 2500) or mask.shape != x.shape:
            raise ValueError("M6 inputs must both have shape (N, 2, 2500)")
        if mask.dtype != np.bool_:
            raise ValueError("M6 validity mask must be boolean")
        if not np.issubdtype(x.dtype, np.number) or not np.isfinite(x[mask]).all():
            raise ValueError("M6 valid samples must be finite numeric values")
        return self._runtime.monitor_batch(self._bundle, x, mask)

"""Independent contract checks for the user-supplied M6 and D research packages."""

import copy
import importlib.util
import json
import unittest
from pathlib import Path

import numpy as np

from sentinelward_ml import SentinelWardDriftMonitor

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / "components" / "SentinelWard_D"


def load_d():
    spec = importlib.util.spec_from_file_location("sentinelward_decision_engine", D / "decision_engine.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class DecisionResearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.engine = load_d()
        cls.policy = json.loads((D / "policy.json").read_text())
        cls.payload = json.loads((D / "example_input.json").read_text())

    def test_example_is_reproducible(self):
        expected = json.loads((D / "example_output.json").read_text())
        self.assertEqual(self.engine.evaluate(self.payload, self.policy), expected)

    def test_emergency_preserved_with_every_other_flag_combination(self):
        for bits in range(8):
            payload = copy.deepcopy(self.payload)
            payload["predictions"]["m2"]["score"] = 0.99
            for i, model in enumerate(("m1", "m3", "m4")):
                payload["predictions"][model]["score"] = 0.99 if bits & (1 << i) else 0.01
            verdict = self.engine.evaluate(payload, self.policy)
            self.assertEqual(verdict["medical_status"], "POTENTIAL_EMERGENCY")
            self.assertEqual(verdict["priority"], "URGENT_REVIEW")

    def test_missing_and_misaligned_fail_safe(self):
        payload = copy.deepcopy(self.payload)
        payload["predictions"]["m2"] = {"status": "unavailable"}
        result = self.engine.evaluate(payload, self.policy)
        self.assertNotEqual(result["medical_status"], "NO_MODEL_ALERT")
        payload = copy.deepcopy(self.payload)
        payload["predictions"]["m2"]["window_id"] = "other"
        with self.assertRaises(ValueError):
            self.engine.evaluate(payload, self.policy)


class DriftResearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.monitor = SentinelWardDriftMonitor()

    def test_insufficient_batch_and_input_contract(self):
        signal = np.zeros((1, 2, 2500), dtype=np.float32)
        mask = np.ones_like(signal, dtype=bool)
        result = self.monitor.monitor(signal, mask)
        self.assertEqual(result["status"], "INSUFFICIENT_DATA")
        with self.assertRaises(ValueError):
            self.monitor.monitor(signal, mask.astype(int))
        with self.assertRaises(ValueError):
            self.monitor.monitor(signal, mask, sample_rate_hz=125)

    def test_complete_batch_returns_advisory_only(self):
        rng = np.random.default_rng(5)
        signal = rng.normal(size=(self.monitor.minimum_batch_size, 2, 2500)).astype(np.float32)
        mask = np.ones_like(signal, dtype=bool)
        result = self.monitor.monitor(signal, mask)
        self.assertTrue(result["research_only"])
        self.assertEqual(result["clinical_action"], "NONE")
        self.assertIn(result["status"], {"DATA_DRIFT_SUSPECTED", "NO_BATCH_DRIFT_ALERT"})


if __name__ == "__main__":
    unittest.main()

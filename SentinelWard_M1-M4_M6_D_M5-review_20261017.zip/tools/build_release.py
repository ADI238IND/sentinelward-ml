"""Build the complete, reproducible research handoff ZIP from Git-visible files."""

from __future__ import annotations

import hashlib
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
NAME = "SentinelWard_M1-M4_M6_D_M5-review_20261017.zip"


def build():
    found = subprocess.check_output(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        cwd=ROOT,
    )
    paths = sorted({Path(raw.decode("utf-8")) for raw in found.split(b"\0") if raw})
    paths = [path for path in paths if path.suffix != ".zip" and (ROOT / path).is_file()]
    if not paths:
        raise RuntimeError("No release files found")
    destination = ROOT / NAME
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6) as archive:
        for path in paths:
            info = zipfile.ZipInfo(path.as_posix(), (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, (ROOT / path).read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=6)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP CRC check failed")
        if len(archive.namelist()) != len(paths):
            raise RuntimeError("Release file count mismatch")
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    print(f"{destination}\nfiles={len(paths)}\nsha256={digest}")


if __name__ == "__main__":
    build()

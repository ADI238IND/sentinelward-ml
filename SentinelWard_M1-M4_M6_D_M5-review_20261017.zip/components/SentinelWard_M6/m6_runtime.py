
"""SentinelWard M6: ECG/PPG feature and drift monitoring.

Research-only data drift detector. No clinical decisions.
"""
import numpy as np
from scipy.signal import welch
from scipy.stats import ks_2samp

VERSION = "M6-1.0-research"

METRICS = [
    "valid_fraction",
    "median",
    "std",
    "iqr",
    "p95_p05",
    "diff_rms",
    "flat_pair_fraction",
    "power_0p5_4_ratio",
    "power_4_15_ratio",
    "power_15_40_ratio"
]

FEATURE_NAMES = [
    f"ch{ch}_{name}"
    for ch in range(2)
    for name in METRICS
]

def extract_one(x, mask, fs=250):
    x = np.asarray(x, dtype=np.float64)
    mask = np.asarray(mask)

    if x.shape != (2, 2500) or mask.shape != x.shape:
        raise ValueError("Expected signals and masks: (2,2500)")

    output = []

    for ch in range(2):
        signal = x[ch]
        good = mask[ch].astype(bool) & np.isfinite(signal)
        valid_fraction = float(good.mean())
        values = signal[good]

        # Very short or entirely missing signals are represented
        # by finite fallback features plus the valid fraction.
        if len(values) < 32:
            output.extend([valid_fraction] + [0.0] * 9)
            continue

        median = float(np.median(values))
        std = float(np.std(values))
        q05, q25, q75, q95 = np.percentile(
            values, [5, 25, 75, 95]
        )

        good_pairs = good[1:] & good[:-1]
        differences = np.diff(signal)[good_pairs]

        if len(differences):
            diff_rms = float(np.sqrt(
                np.mean(differences ** 2)
            ))
            flat_fraction = float(np.mean(
                np.abs(differences) <= max(1e-6, 0.001 * std)
            ))
        else:
            diff_rms = 0.0
            flat_fraction = 1.0

        # Interpolate invalid samples for PSD extraction.
        # Validity itself is tracked separately.
        indices = np.arange(signal.size)
        interpolated = np.interp(
            indices, indices[good], signal[good]
        )

        freq, psd = welch(
            interpolated - median,
            fs=fs,
            nperseg=512,
            noverlap=256
        )

        total = float(
            psd[(freq >= 0.5) & (freq < 40)].sum()
        )

        def ratio(low, high):
            if total <= 1e-20:
                return 0.0
            return float(
                psd[(freq >= low) & (freq < high)].sum()
                / total
            )

        output.extend([
            valid_fraction,
            median,
            std,
            float(q75 - q25),
            float(q95 - q05),
            diff_rms,
            flat_fraction,
            ratio(0.5, 4),
            ratio(4, 15),
            ratio(15, 40)
        ])

    result = np.asarray(output, dtype=np.float64)

    if not np.isfinite(result).all():
        raise ValueError("Non-finite extracted feature")

    return result


def extract_many(signals, masks, fs=250):
    signals = np.asarray(signals)
    masks = np.asarray(masks)

    if signals.ndim != 3 or signals.shape[1:] != (2, 2500):
        raise ValueError("Expected signal shape (N,2,2500)")
    if masks.shape != signals.shape:
        raise ValueError("Mask shape mismatch")

    return np.asarray([
        extract_one(x, m, fs)
        for x, m in zip(signals, masks)
    ], dtype=np.float64)


def batch_components(bundle, features):
    """Compute raw unsupervised drift evidence."""
    features = np.asarray(features, dtype=np.float64)
    baseline = bundle["reference_features"]

    if features.ndim != 2 or features.shape[1] != len(FEATURE_NAMES):
        raise ValueError("Incorrect feature dimensions")
    if not np.isfinite(features).all():
        raise ValueError("Non-finite feature matrix")

    scaled = bundle["scaler"].transform(features)
    anomaly_scores = -bundle["forest"].score_samples(scaled)

    ood_fraction = float(np.mean(
        anomaly_scores > bundle["window_ood_threshold"]
    ))

    ks = np.asarray([
        ks_2samp(
            baseline[:, j],
            features[:, j],
            method="asymp"
        ).statistic
        for j in range(features.shape[1])
    ])

    top_three_ks = float(np.mean(np.sort(ks)[-3:]))

    return {
        "ood_fraction": ood_fraction,
        "ks_top3_mean": top_three_ks,
        "ks_by_feature": ks
    }


def monitor_features(bundle, features):
    """Monitor one batch of precomputed feature vectors."""
    features = np.asarray(features, dtype=np.float64)

    if features.ndim != 2 or features.shape[1] != len(FEATURE_NAMES):
        raise ValueError("Incorrect feature dimensions")
    if not np.isfinite(features).all():
        raise ValueError("Non-finite feature matrix")

    count = len(features)
    minimum = int(bundle["minimum_batch_size"])

    if count < minimum:
        return {
            "status": "INSUFFICIENT_DATA",
            "alert": None,
            "observed_windows": count,
            "minimum_windows": minimum,
            "research_only": True
        }

    components = batch_components(bundle, features)

    ood = components["ood_fraction"]
    ks = components["ks_top3_mean"]

    scales = bundle["score_scales"]

    drift_score = float(max(
        ood / scales["ood_fraction"],
        ks / scales["ks_top3_mean"]
    ))

    threshold = float(bundle["batch_drift_threshold"])
    alert = bool(drift_score > threshold)

    order = np.argsort(
        components["ks_by_feature"]
    )[::-1][:5]

    top = [
        {
            "feature": FEATURE_NAMES[int(j)],
            "ks_statistic": float(
                components["ks_by_feature"][j]
            )
        }
        for j in order
    ]

    return {
        "version": VERSION,
        "status": (
            "DATA_DRIFT_SUSPECTED"
            if alert else "NO_BATCH_DRIFT_ALERT"
        ),
        "alert": alert,
        "observed_windows": count,
        "window_ood_fraction": ood,
        "top3_ks_mean": ks,
        "drift_score": drift_score,
        "batch_threshold": threshold,
        "top_shifted_features": top,
        "calibration_source": "train_record_holdout",
        "research_only": True,
        "clinical_action": "NONE",
        "note": (
            "Drift alert is advisory, not a diagnosis, "
            "attack confirmation, or device-freshness proof."
        )
    }


def monitor_batch(bundle, signals, masks):
    features = extract_many(signals, masks)
    return monitor_features(bundle, features)


def compare_model_scores(reference, current, minimum=32):
    """Exploratory M1-M4 prediction distribution comparison.

    This is intentionally NOT a calibrated alert generator.
    Actual score telemetry baselines are still required.
    """
    results = {}

    for model in ["m1", "m2", "m3", "m4"]:
        if model not in reference or model not in current:
            results[model] = {"status": "NOT_ASSESSED"}
            continue

        a = np.asarray(reference[model], dtype=float)
        b = np.asarray(current[model], dtype=float)

        if (
            a.ndim != 1 or b.ndim != 1
            or not np.isfinite(a).all()
            or not np.isfinite(b).all()
            or np.any((a < 0) | (a > 1))
            or np.any((b < 0) | (b > 1))
        ):
            raise ValueError(f"Invalid model scores: {model}")

        if min(len(a), len(b)) < minimum:
            results[model] = {"status": "INSUFFICIENT_DATA"}
            continue

        results[model] = {
            "status": "UNCALIBRATED_COMPARISON",
            "reference_count": len(a),
            "current_count": len(b),
            "ks_statistic": float(
                ks_2samp(a, b).statistic
            ),
            "median_score_change": float(
                np.median(b) - np.median(a)
            ),
            "alert": None
        }

    return results


"""
SentinelWard Decision Engine
Version: D-1.0-research

Combines four model outputs into independent medical,
signal-quality, and security assessments.

Research software. Not clinically validated.
No medical alert is suppressed by a security warning.
"""

import copy
import math
from numbers import Number

VERSION = "D-1.0-research"

LABELS = {
    "m1": "unacceptable_signal_quality",
    "m2": "potential_medical_emergency",
    "m3": "ecg_ppg_inconsistency",
    "m4": "replay_similarity"
}

def default_policy():
    return {
        "version": VERSION,
        "research_only": True,
        "models": {
            "m1": {
                "positive_label": LABELS["m1"],
                "threshold": 0.50,
                "threshold_source": "illustrative",
                "validated": False
            },
            "m2": {
                "positive_label": LABELS["m2"],
                "threshold": 0.50,
                "threshold_source": "illustrative",
                "validated": False
            },
            "m3": {
                "positive_label": LABELS["m3"],
                "threshold": 0.50,
                "threshold_source": "illustrative",
                "validated": False
            },
            "m4": {
                "positive_label": LABELS["m4"],
                "threshold": 0.9338677094352905,
                "threshold_source": "V3_synthetic_development",
                "validated": False
            }
        }
    }


def numeric_score(value, field):
    if isinstance(value, (bool, str, bytes)):
        raise ValueError(f"{field}: invalid numeric type")

    if not isinstance(value, Number):
        raise ValueError(f"{field}: expected numeric score")

    try:
        score = float(value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError(f"{field}: cannot convert to float")

    if not math.isfinite(score) or not 0 <= score <= 1:
        raise ValueError(
            f"{field}: score must be finite and within [0,1]"
        )
    return score


def validate_policy(policy):
    if not isinstance(policy, dict):
        raise ValueError("Policy must be a dictionary")

    models = policy.get("models")
    if not isinstance(models, dict) or set(models) != set(LABELS):
        raise ValueError("Policy must define exactly M1-M4")

    for name, expected_label in LABELS.items():
        config = models[name]
        if not isinstance(config, dict):
            raise ValueError(f"Invalid policy for {name}")

        if config.get("positive_label") != expected_label:
            raise ValueError(
                f"{name}: output polarity is not verified"
            )

        numeric_score(
            config.get("threshold"),
            f"{name} threshold"
        )

        if not isinstance(config.get("validated"), bool):
            raise ValueError(
                f"{name}: validated must be boolean"
            )

        if not config.get("threshold_source"):
            raise ValueError(
                f"{name}: threshold source missing"
            )

    if policy.get("research_only") is not True:
        raise ValueError(
            "Current engine must remain research-only "
            "until independent system validation."
        )


def build_payload(window_id, scores):
    """
    Convenience adapter for TEST inputs only.
    Real integrations must verify output label polarity,
    timestamp, model version, and sample alignment.
    """
    if not isinstance(scores, dict):
        raise ValueError("Scores must be a dictionary")

    if set(scores) - set(LABELS):
        raise ValueError("Unknown model in scores")

    predictions = {}

    for model in LABELS:
        value = scores.get(model)

        if value is None:
            predictions[model] = {
                "status": "unavailable"
            }
        else:
            predictions[model] = {
                "status": "ok",
                "score": value,
                "positive_label": LABELS[model],
                "window_id": window_id
            }

    return {
        "window_id": window_id,
        "predictions": predictions
    }


def evaluate(payload, policy=None):
    """
    Evaluate one synchronized set of model predictions.

    A positive M2 signal is never cleared by M1/M3/M4.
    Missing outputs prevent a fully clear result.
    All thresholds are research/demonstration values.
    """
    if policy is None:
        policy = default_policy()

    validate_policy(policy)

    if not isinstance(payload, dict):
        raise ValueError("Input must be a dictionary")

    window_id = payload.get("window_id")
    if not isinstance(window_id, str) or not window_id.strip():
        raise ValueError("Valid window_id is required")

    predictions = payload.get("predictions")
    if not isinstance(predictions, dict):
        raise ValueError("Missing predictions dictionary")

    unknown = set(predictions) - set(LABELS)
    if unknown:
        raise ValueError(f"Unknown model IDs: {unknown}")

    checks = {}
    flags = {}
    reasons = []
    missing = []
    warnings = []
    actions = []

    for name in LABELS:
        config = policy["models"][name]
        raw = predictions.get(name)

        if raw is None:
            raw = {"status": "unavailable"}

        if not isinstance(raw, dict):
            raise ValueError(f"{name}: invalid model output")

        status = raw.get("status", "ok")

        if status == "unavailable":
            if "score" in raw:
                raise ValueError(
                    f"{name}: unavailable output contains score"
                )

            flags[name] = None
            missing.append(name)
            reasons.append(f"{name.upper()}_NOT_ASSESSED")

            checks[name] = {
                "status": "NOT_ASSESSED",
                "score": None,
                "threshold": config["threshold"],
                "flagged": None,
                "positive_label": LABELS[name]
            }
            continue

        if status != "ok":
            raise ValueError(
                f"{name}: unsupported output status"
            )

        if raw.get("window_id") != window_id:
            raise ValueError(
                f"{name}: window alignment mismatch"
            )

        if raw.get("positive_label") != LABELS[name]:
            raise ValueError(
                f"{name}: incorrect positive-class meaning"
            )

        score = numeric_score(
            raw.get("score"), f"{name} score"
        )

        threshold = numeric_score(
            config["threshold"], f"{name} threshold"
        )

        flagged = score >= threshold
        flags[name] = flagged

        checks[name] = {
            "status": "ASSESSED",
            "score": score,
            "threshold": threshold,
            "flagged": flagged,
            "positive_label": LABELS[name],
            "threshold_source": config["threshold_source"],
            "threshold_validated": config["validated"]
        }

        if not config["validated"]:
            warnings.append(
                f"{name.upper()}_THRESHOLD_NOT_VALIDATED"
            )

    # --------------------------------------------------------
    # MEDICAL DECISION
    # A potential emergency always retains its warning.
    # --------------------------------------------------------
    if flags["m2"] is True:
        medical = "POTENTIAL_EMERGENCY"
        reasons.append("M2_EMERGENCY_FLAG")
        actions.append("PROMPT_CLINICAL_REVIEW")

    elif (
        flags["m2"] is None
        or missing
        or flags["m1"] is True
        or flags["m3"] is True
        or flags["m4"] is True
    ):
        medical = "INDETERMINATE"

    else:
        medical = "NO_MODEL_ALERT"

    # --------------------------------------------------------
    # SIGNAL QUALITY
    # --------------------------------------------------------
    if flags["m1"] is True:
        reasons.append("M1_POOR_SIGNAL_QUALITY")

    if flags["m3"] is True:
        reasons.append("M3_PHYSIOLOGICAL_INCONSISTENCY")

    if flags["m1"] is True or flags["m3"] is True:
        signal = "REVIEW_REQUIRED"
        actions.append("RECHECK_SENSOR_SIGNAL")

    elif flags["m1"] is None or flags["m3"] is None:
        signal = "PARTIALLY_ASSESSED"

    else:
        signal = "ACCEPTABLE_BY_MODELS"

    # --------------------------------------------------------
    # SECURITY DECISION
    # --------------------------------------------------------
    if flags["m4"] is True:
        security = "POSSIBLE_REPLAY"
        reasons.append("M4_REPLAY_SIMILARITY_FLAG")
        actions.append("INVESTIGATE_SIGNAL_FRESHNESS")

    elif flags["m4"] is None:
        security = "NOT_ASSESSED"

    else:
        security = "NO_REPLAY_FLAG"

    if missing:
        actions.append("RECOVER_MISSING_MODEL_OUTPUTS")

    review = (
        medical != "NO_MODEL_ALERT"
        or signal != "ACCEPTABLE_BY_MODELS"
        or security != "NO_REPLAY_FLAG"
    )

    if flags["m2"] is True:
        priority = "URGENT_REVIEW"
    elif review:
        priority = "REVIEW_REQUIRED"
    else:
        priority = "NO_MODEL_ALERT"

    if not actions:
        actions.append("CONTINUE_ROUTINE_MONITORING")

    # Never treat model output as proof of freshness
    # or absence of a genuine medical emergency.
    return {
        "engine_version": VERSION,
        "window_id": window_id,
        "medical_status": medical,
        "signal_status": signal,
        "security_status": security,
        "priority": priority,
        "human_review_required": review,
        "reasons": reasons,
        "recommended_actions": actions,
        "missing_models": missing,
        "model_checks": checks,
        "validation_warnings": warnings,
        "research_only": True,
        "ready_for_live_use": False
    }

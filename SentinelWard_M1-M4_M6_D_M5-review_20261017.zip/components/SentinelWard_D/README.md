# SentinelWard Decision Engine D

Version: D-1.0-research

## Purpose

Combine independent quality, medical, consistency, and
replay-detection model outputs into explainable decisions.

## Input models

M1: Sensor quality score (positive means unacceptable)
M2: Potential medical emergency score
M3: ECG-PPG inconsistency score
M4: Replay-similarity score

## Engine behavior

- Preserves M2 emergency warnings independently.
- Reports suspected replay activity separately.
- Flags unreliable physiological signals.
- Handles missing model predictions.
- Rejects incorrect score polarity and mismatched window IDs.
- Returns auditable reason codes and model-score traces.

## Run locally

Place decision_engine.py and policy.json together.

```python
import json
from decision_engine import evaluate

with open("policy.json") as f:
    policy = json.load(f)

with open("example_input.json") as f:
    payload = json.load(f)

result = evaluate(payload, policy)

print(json.dumps(result, indent=2))
```

## Input requirements

Scores must be finite numbers from zero to one.
Positive-label meanings must match the model contract.
Every available prediction must use the same window ID.

Real integrations must separately verify device identity,
actual acquisition time, model version, and stream freshness.

## Current validation

- Synthetic 16-combination rule matrix
- Emergency-preservation property tests
- Missing-input handling tests
- Invalid-input and policy tests
- Reproducible JSON response tests
- Export and reload smoke testing

See test_summary.json and decision_matrix.csv.

## Important limitations

This is a research prototype, not a clinically validated
medical decision-support or operational security system.

M1-M3 thresholds are illustrative pending verification.
M4 uses a threshold from a small synthetic development study.

Do not use model output to automatically suppress,
delay, or cancel a possible emergency response.

This engine does not prove that ECG/PPG data is fresh.
Actual replay protection requires authenticated messages,
trusted sequencing, and verified timing.

## Integration requirements

1. Verify each model's positive-class interpretation.
2. Supply thresholds from independent validation.
3. Verify that predictions refer to the same data window.
4. Add authenticated device-origin and freshness checks.
5. Independently evaluate the full integrated system.

## Dependencies

Engine: Python standard library only.
Colab reports: pandas, numpy, and standard Colab packages.

## Owner

IBM SentinelWard project team.

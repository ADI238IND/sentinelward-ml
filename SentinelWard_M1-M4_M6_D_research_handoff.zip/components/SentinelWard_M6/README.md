# IBM SentinelWard — Model 6

## Purpose

Research-only drift monitoring for ECG–PPG waveform streams.

M6 combines:
1. Isolation Forest anomaly scores on waveform features.
2. Kolmogorov–Smirnov feature-distribution comparisons.
3. A train-calibrated batch alert threshold.

M6 does NOT diagnose medical conditions, prove replay attacks,
or authorize automated medical decisions.

## Input

Signal tensor: (N, 2, 2500)
Validity mask: (N, 2, 2500)
Sampling rate: 250 Hz
Minimum N: read minimum_batch_size from model artifact.

Channel mapping has not yet been independently verified.
Do not assume ch0/ch1 physiological identity without checking
the original preprocessing manifest.

## Development protocol

- VTAC native 250 Hz cache.
- One eligible window selected per record.
- Baseline and calibration records are disjoint.
- Original validation record IDs are held out.
- No VTAC class label is used to fit the drift monitor.
- Batch threshold derived from calibration resampling.
- Stress tests modify held-out waveforms synthetically.

This verifies record-level separation, not patient-level separation.

## Load and run

```python
import joblib
from m6_runtime import monitor_batch

bundle = joblib.load("sentinelward_m6_drift_v1.joblib")
result = monitor_batch(bundle, signals, valid_masks)
print(result)
```

Only load trusted model artifacts. Joblib files may execute
Python code during deserialization.

## Output

status: DATA_DRIFT_SUSPECTED / NO_BATCH_DRIFT_ALERT /
        INSUFFICIENT_DATA
alert: true / false / null
drift_score: composite distribution-shift statistic
batch_threshold: development calibration threshold
top_shifted_features: largest feature-wise KS statistics

## M1–M4 model-score monitoring

The module also contains compare_model_scores().
This computes descriptive changes to prediction-score
distributions but intentionally does not issue alerts yet.

Actual model-score reference histories must be collected and
their alert thresholds calibrated before claiming that
M1–M4 model-output drift monitoring is operational.

## Important limitations

- Simulated changes are not real observed deployment drift.
- The validation set is from the same overall dataset.
- Patient-level separation is not established.
- Small numbers of distinct validation batches give uncertain
  estimates of false-alert and scenario-detection rates.
- Thresholds are research estimates and need external testing.
- Drift is not necessarily malicious; population, device,
  preprocessing, or environment changes can cause it.
- M6 alerts must not automatically cancel emergency warnings.
- No clinical or operational deployment approval is implied.

## Files

m6_runtime.py                 Reusable inference code
sentinelward_m6_drift_v1.joblib   Fitted drift detector
feature_catalog.json         Input feature contract
metrics.json                 Validation results
scenario_summary.csv         Scenario-level comparison
validation_batch_results.csv  Per-batch results
calibration_bootstraps.csv    Threshold calibration evidence
package_smoke_tests.csv       Inference regression checks
plots/                        Calibration and stress-test charts

## Dependencies

numpy, pandas, scipy, scikit-learn, joblib

## Version

M6-1.0-research
